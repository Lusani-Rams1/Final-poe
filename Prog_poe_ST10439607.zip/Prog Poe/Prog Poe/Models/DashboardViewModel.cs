﻿using System.Collections.Generic;

namespace Prog_Poe.Models
{
    public class DashboardViewModel
    {
        public List<Claim> Claims { get; set; }

        // Stat Cards
        public int TotalClaims { get; set; }
        public int PendingCount { get; set; }
        public double ApprovedValue { get; set; }
        public int RejectedCount { get; set; }

        // Chart Data (Passed to JavaScript)
        public int PendingPie { get; set; }
        public int ApprovedPie { get; set; }
        public int RejectedPie { get; set; }

        // Mock Monthly Data (Jan, Feb, Mar/Current)
        public double[] MonthlyValues { get; set; }
    }
}