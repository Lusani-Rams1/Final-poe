﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Prog_Poe.Models;
using System;
using System.IO;
using System.Threading.Tasks;

public class CreateModel : PageModel
{
    [BindProperty]
    public Claim Claim { get; set; }

    [BindProperty]
    public IFormFile Upload { get; set; }

    public void OnGet()
    {
        Claim = new Claim
        {
            SubmissionDate = DateTime.Now,
            Status = ClaimStatus.Pending
        };
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        // Validate File
        if (Upload == null)
        {
            ModelState.AddModelError("Claim.FileName", "The FileName field is required.");
            return Page();
        }

        // Save uploaded file
        var filePath = Path.Combine("wwwroot/uploads", Upload.FileName);
        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await Upload.CopyToAsync(stream);
        }

        Claim.FileName = Upload.FileName;

        // Calculate amount
        Claim.Amount = Claim.TotalAmount;
        Claim.Id = Guid.NewGuid().ToString();

        // TODO: Save to database

        return RedirectToPage("Success");
    }
}
